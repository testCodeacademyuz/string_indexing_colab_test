from setuptools import setup

setup(
   name='string_indexing',
   version='0.1.0',
   packages=['string_indexing'],
   description='This is String Indexing Test',
   install_requires=[
       "requests",
   ]
)